function showSurprise() {
  const surprise = document.getElementById('surprise');
  surprise.classList.remove('hidden');
  surprise.style.display = 'block';
}
